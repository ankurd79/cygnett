<?php

class Team_model extends CI_model{
 
  public function __construct() {
           parent::__construct(); 
           $this->load->model('Common_model');
           

  }
 
 public function insertData($data,$user){
        //print_r($data);
        //exit;
        $chkVal=$this->Common_model->chkDuplicateDataOccurence(team,$data['email'],'email');
        if($chkVal==1){
            if( empty($data["is_active"]) ) {
                  $pshow=0;
            }else{
                  $pshow=1;
            }
            
            if(empty($data["is_mgmt"]) ) {
                  $is_mgmt=0;
            }else{
                  $is_mgmt=1;
            }



            if($_FILES["image"]['name']<>''){
                $fileforupload=$_FILES["image"]['name'];
                $uploadedfile=uploadcustomImg($fileforupload,folder_team,"image");
                //$imgArr=array('logo_image'=>$uploadedfile);
                //$finalArray=array_merge($ins_arr_1,$imgArr);           
            }else{
                //$finalArray=$ins_arr_1;
                $uploadedfile='';
            }
            
            if($_FILES["mobile_image"]['name']<>''){
                $fileforupload2=$_FILES["mobile_image"]['name'];
                $uploadedfile2=uploadcustomImg($fileforupload2,folder_team,"mobile_image");
                //$imgArr2=array('secondary_logo'=>$uploadedfile2);
                //$finalArray=array_merge($ins_arr_1,$imgArr2);           
            }else{
                //$finalArray=$ins_arr_1;
                $uploadedfile2='';
            }




            $finalArray=array('first_name'=>$data['first_name'],'middle_name'=>$data['middle_name'],
              'last_name'=>$data['last_name'],'job_title'=>$data['job_title'],
              'salutation'=>$data['salutation'],'department_id'=>$data['department_id'],
              'designation_id'=>$data['designation_id'],
              'email'=>$data['email'],'mobile'=>$data['mobile'],
              'position'=>$data['position'],
              'image'=>$uploadedfile,
              'mobile_image'=>$uploadedfile2,
              'added_on'=> date_stamp(),'added_by' => $user,'is_active'=>$pshow, 'is_mgmt'=>$is_mgmt);

            $this->db->insert(team,$finalArray);
            $lastinsertedId = $this->db->insert_id();

            /**********send data to pointers table*******/
            $highlights = isset($data['highlights']) ? $data['highlights'] : "" ;
            #$lastinsertedId=1;

              foreach($highlights as $key=>$value){
                  if(strlen($highlights[$key])>0){
                    $arrInsert=array('member_id'=>$lastinsertedId,'highlights'=>$highlights[$key],'added_on'=> date_stamp(),'added_by' => $user,'is_active'=>1);
                      $this->db->insert(highlights,$arrInsert);
                    }
              }
  

            /**********send data to pointers table*******/


        $msg=1;
        }else{
            $msg=0;
        }
    return $msg;
}


public function updateData($data,$user){
            $updateid=base64_decode($data['member_id']);
            if( empty($data["is_active"]) ) {
                  $pshow=0;
            }else{
                  $pshow=1;
            }

            if(empty($data["is_mgmt"]) ) {
                  $is_mgmt=0;
            }else{
                  $is_mgmt=1;
            }
           
           
              $finalArray=array('first_name'=>$data['first_name'],'middle_name'=>$data['middle_name'],
              'last_name'=>$data['last_name'],'job_title'=>$data['job_title'],
              'salutation'=>$data['salutation'],'department_id'=>$data['department_id'],
              'designation_id'=>$data['designation_id'],
              'email'=>$data['email'],'mobile'=>$data['mobile'],
              'position'=>$data['position'],
              'updated_on'=> date_stamp(),'updated_by' => $user,'is_active'=>$pshow,'is_mgmt'=>$is_mgmt);

            if($_FILES["image"]['name']<>''){

                $fileforupload=$_FILES["image"]['name'];
                $uploadedfile=uploadcustomImg($fileforupload,folder_brand,"image");
                $imgArr=array('image'=>$uploadedfile);
                $finalArray=array_merge($finalArray,$imgArr);
               
            }

            if($_FILES["mobile_image"]['name']<>''){
                $fileforupload2=$_FILES["mobile_image"]['name'];
                $uploadedfile2=uploadcustomImg($fileforupload2,folder_brand,"mobile_image");
                $imgArr2=array('mobile_image'=>$uploadedfile2);
                $finalArray=array_merge($finalArray,$imgArr2);           
            }

            
              $this->db->where('id',$updateid);     
              $this->db->update(team,$finalArray);

              /**********send data to highlights table*******/
                $highlights = isset($data['highlights']) ? $data['highlights'] : "" ;


                foreach($highlights as $key=>$value){
                    if(strlen($highlights[$key])>0){
                      
                      if(isset($data['highlight_id'][$key])){
                          $arrhighUpdate=array('highlights'=>$data['highlights'][$key],'updated_on'=> date_stamp(),'updated_by' => $user);
                          $this->db->where('id',$data['highlight_id'][$key]);
                          $this->db->update(highlights,$arrhighUpdate);
                      }else{
                          $arrhighInsert=array('member_id'=>$updateid,'highlights'=>$data['highlights'][$key],'added_on'=> date_stamp(),'added_by' => $user,'is_active'=>1);
                          $this->db->insert(highlights,$arrhighInsert);
                      }
                }
              }

          /**********send data to highlights table*******/
        
        

        $msg=1;
        
    return $msg;
}


    public function getdatas($id='',$site=''){
        $this->db->select('*');
        
        if($id>0){
          $this->db->where('id', $id); 
        }
        if($site=='1'){
            $this->db->where('is_active',1);
            $this->db->order_by('first_name','ASC');
        }
        
        $this->db->from(team);
        
      
      if($query=$this->db->get()){
        //echo $this->db->last_query();
          //return $query->row_array();
          return $query->result_array();
      }else{
        return false;
      } 

    }

    public function getdata($id='',$site=''){

      $this->db->select('t.*,dept.deptt_name, desig.designation'); 
      $this->db->from(team. ' t');
      $this->db->join(department .' dept', 'dept.id = t.department_id'); 
      $this->db->join(designation .' desig', 'desig.id = t.designation_id'); 
      
      if($id>0){
          $this->db->where('t.id', $id); 
      }

      if($site=='1'){
            $this->db->where('t.is_active',1);
      }

      $this->db->order_by('t.first_name','ASC'); 

      if($query=$this->db->get()){
        //echo $this->db->last_query();
          //return $query->row_array();
          return $query->result_array();
      }else{
        return false;
      }

    }

    public function deleteData($data){

                $this->db->where('id', $data['id']);
                $this->db->delete(team);
                
                $msg=1;
                return $msg;
    }

    
    public function gethighlightsofamember($id){
        $this->db->select('*');
        $this->db->where('member_id',$id);
        $this->db->order_by('id','ASC');
        $this->db->from(highlights);
        
      
        if($query=$this->db->get()){
          //echo $this->db->last_query();
            //return $query->row_array();
            return $query->result_array();
        }else{
          return false;
        } 
    }  
    

    









}












<?php 
  
      $devicetye=devicedetector($_SERVER['HTTP_USER_AGENT']);
      if($devicetye=='mobile'){
          $image1='generic-img1-mob.jpg';
          $image2='generic-img2-mob.jpg';
      }else{
      //$deviceused='Desktop';
          $image1='generic-img1.jpg';
          $image2='generic-img2.jpg';
      }
?>

			<div role="main" class="main">
				<!-- Top Carousel -->
				<div id="carouselExampleControls" class="carousel slide" data-ride="carousel" data-interval="3000">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="<?php echo base_url() ?>images/static/<?php echo $image1 ?>" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="<?php echo base_url() ?>images/static/<?php echo $image2 ?>" alt="Second slide">
    </div>
    
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
  <?php $this->load->view('site/booking-widget');?>
</div>